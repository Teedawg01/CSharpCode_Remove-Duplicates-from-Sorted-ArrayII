using System;
using AlgorithmLogic;

namespace Application
{
    class Program
    {
        static void Main(string[] args)
        {
            Solution solution = new Solution();
            
            
            int[] nums1 = {1, 1, 1, 2, 2, 3};
            Console.WriteLine("Test Case 1:");
            Console.WriteLine($"Input: [{string.Join(",", nums1)}]");
            int k1 = solution.RemoveDuplicates(nums1);
            Console.Write($"Output: {k1}, nums = [");
            for (int i = 0; i < k1; i++)
            {
                Console.Write(nums1[i]);
                if (i < k1 - 1)
                 Console.Write(",");
            }
            Console.WriteLine("]");
            
          
            int[] nums2 = {0, 0, 1, 1, 1, 1, 2, 3, 3};
            Console.WriteLine("\nTest Case 2:");
            Console.WriteLine($"Input: [{string.Join(",", nums2)}]");
            int k2 = solution.RemoveDuplicates(nums2);
            Console.Write($"Output: {k2}, nums = [");
            for (int i = 0; i < k2; i++)
            {
                Console.Write(nums2[i]);
                if (i < k2 - 1)
                 Console.Write(",");
            }
            Console.WriteLine("]");
        }
    }
}